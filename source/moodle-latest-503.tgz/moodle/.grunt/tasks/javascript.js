// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/* jshint node: true, browser: false */
/* eslint-env node */

/**
 * @copyright  2021 Andrew Nicols
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Function to generate the destination for the minification task
 * (e.g. build/file.min.js). This function will be passed to
 * the rename property of files array when building dynamically:
 * http://gruntjs.com/configuring-tasks#building-the-files-object-dynamically
 *
 * @param {String} destPath the current destination
 * @param {String} srcPath the  matched src path
 * @return {String} The rewritten destination path.
 */
const babelRename = function(destPath, srcPath) {
    destPath = srcPath.replace(`amd/src`, `amd/build`);
    destPath = destPath.replace(/\.js$/, '.min.js');
    return destPath;
};

module.exports = grunt => {
    // Load the React build tasks.
    require('./esm')(grunt);

    // Load the Ignorefiles tasks.
    require('./ignorefiles')(grunt);

    // Load the Shifter tasks.
    require('./shifter')(grunt);

    // Load ESLint.
    require('./eslint')(grunt);

    // Load jsconfig.
    require('./jsconfig')(grunt);

    // Load JSDoc.
    require('./jsdoc')(grunt);

    const path = require('path');

    // Register JS tasks.
    grunt.registerTask('yui', ['eslint:yui', 'shifter']);
    grunt.registerTask('amd', ['ignorefiles', 'eslint:amd', 'rollup', 'amdtypes']);
    grunt.registerTask('js', ['amd', 'yui', 'esm']);

    // Generate .d.ts declarations for AMD source files (best-effort).
    // Respects --files, inComponent, and watch-narrowed file lists so only
    // the affected sources are recompiled.
    grunt.registerTask('amdtypes', 'Generate AMD type declarations', function() {
        const ts = require('typescript');
        const glob = require('glob');
        const typesBaseDir = path.resolve('.types', 'amd');

        // Determine which source files to process.
        // Priority: explicit --files > amdSrc globs (already component-scoped when inComponent).
        let srcFiles = [];
        grunt.log.ok('amdtypes: determining source files to process...');
        if (grunt.moodleEnv.files) {
            // Explicit file list from --files flag or watch event.
            grunt.moodleEnv.files.forEach((file) => {
                if (file.match(/\/amd\/src\//)) {
                    grunt.log.debug(`amdtypes: adding explicitly matched file ${file}`);
                    srcFiles.push(file);
                } else {
                    grunt.log.warn(`amdtypes: skipping explicitly matched file ${file} because it does not match /amd/src/`);
                    srcFiles.push(path.join(file, 'amd', 'src', '**', '*.js'));
                }
            });
        } else {
            // Expand the amdSrc globs (component-scoped or full tree).
            srcFiles = grunt.file.expand(grunt.moodleEnv.amdSrc)
                .map(f => path.resolve(f));
        }

        if (srcFiles.length === 0) {
            grunt.log.ok('amdtypes: nothing to process.');
            return;
        }

        // Group files by their amd/src root so we can set rootDir per component.
        /** @type {Map<string, string[]>} srcDir -> [absolute file paths] */
        const groups = new Map();
        for (const file of srcFiles) {
            const [componentDir] = file.split('/amd/src/');
            if (!groups.has(componentDir)) {
                groups.set(componentDir, []);
            }

            if (file.match(/\/amd\/src\//)) {
                groups.get(componentDir).push(...glob.sync(file));
            } else {
                groups.get(componentDir).push(...glob.sync(path.join(file, 'amd', 'src', '**', '*.js')));
            }
        }

        grunt.log.ok(`amdtypes: processing ${srcFiles.length} file(s) across ${groups.size} component(s).`);

        const gruntRoot = path.resolve('.');
        for (const [componentDir, files] of groups) {
            // Map componentDir back to a componentPath-relative output dir.
            // Format: componentDir = <root>/public/lib -> componentPath = public/lib.
            const componentPath = path.relative(gruntRoot, componentDir); // Path: `public/lib`.
            const srcDir = path.join(componentDir, 'amd', 'src'); // Path: `<root>/public/lib/amd/src`.
            const outDir = path.join(typesBaseDir, componentPath);

            const options = {
                declaration: true,
                emitDeclarationOnly: true,
                allowJs: true,
                outDir,
                rootDir: srcDir,
                skipLibCheck: true,
            };

            const program = ts.createProgram(files, options);
            program.emit();
            grunt.log.write('.');
        }
        grunt.log.writeln('');

        grunt.log.ok(`amdtypes: generated declarations for ${srcFiles.length} file(s).`);
    });

    // Register NPM tasks.
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-rollup');

    const babelTransform = require('@babel/core').transform;
    const babel = (options = {}) => {
        return {
            name: 'babel',

            transform: (code, id) => {
                grunt.log.debug(`Transforming ${id}`);
                options.filename = id;
                const transformed = babelTransform(code, options);

                return {
                    code: transformed.code,
                    map: transformed.map
                };
            }
        };
    };

    // Note: We have to use a rate limit plugin here because rollup runs all tasks asynchronously and in parallel.
    // When we kick off a full run, if we kick off a rollup of every file this will fork-bomb the machine.
    // To work around this we use a concurrent Promise queue based on the number of available processors.
    const rateLimit = () => {
        const queue = [];
        let queueRunner;

        const startQueue = () => {
            if (queueRunner) {
                return;
            }

            queueRunner = setTimeout(() => {
                const limit = Math.max(1, require('os').cpus().length / 2);
                grunt.log.debug(`Starting rollup with queue size of ${limit}`);
                runQueue(limit);
            }, 100);
        };

        // The queue runner will run the next `size` items in the queue.
        const runQueue = (size = 1) => {
            queue.splice(0, size).forEach(resolve => {
                grunt.log.debug(`Item resolved. Kicking off next one.`);
                resolve();
            });
        };

        return {
            name: 'ratelimit',

            // The options hook is run in parallel.
            // We can return an unresolved Promise which is queued for later resolution.
            options: async(options) => {
                return new Promise(resolve => {
                    queue.push(resolve);
                    startQueue();
                    return options;
                });
            },

            // When an item in the queue completes, start the next item in the queue.
            generateBundle: (options, bundle) => {
                grunt.log.debug(`Finished output phase for ${Object.keys(bundle).join(', ')}`);
                runQueue();
            },
        };
    };

    const terser = require('rollup-plugin-terser').terser;
    grunt.config.merge({
        rollup: {
            options: {
                format: 'esm',
                dir: 'output',
                sourcemap: true,
                treeshake: false,
                context: 'window',
                plugins: [
                    rateLimit(),
                    babel({
                        sourceMaps: true,
                        comments: false,
                        compact: false,
                        plugins: [
                            'transform-es2015-modules-amd-lazy',
                            'system-import-transformer',
                            // This plugin modifies the Babel transpiling for "export default"
                            // so that if it's used then only the exported value is returned
                            // by the generated AMD module.
                            //
                            // It also adds the Moodle plugin name to the AMD module definition
                            // so that it can be imported as expected in other modules.
                            path.resolve('.grunt/babel-plugin-add-module-to-define.js')
                        ],
                        presets: [
                            ['@babel/preset-env', {
                                modules: false,
                                useBuiltIns: false,
                                // Explicit targets prevent browserslist query resolution from
                                // affecting compiled output as browser release schedules change.
                                // These values match the minimum browser versions from the
                                // browserslist query at the time this was pinned (early 2022 data).
                                ignoreBrowserslistConfig: true,
                                targets: {
                                    chrome: '93',
                                    edge: '96',
                                    firefox: '95',
                                    safari: '13.1',
                                    ios: '12.2',
                                    samsung: '15',
                                },
                            }]
                        ]
                    }),

                    terser({
                        // Do not mangle variables.
                        // Makes debugging easier.
                        mangle: false,
                    }),
                ],
            },
            dist: {
                files: [{
                    expand: true,
                    src: grunt.moodleEnv.files ? grunt.moodleEnv.files : grunt.moodleEnv.amdSrc,
                    rename: babelRename
                }],
            },
        },
    });

    grunt.config.merge({
        watch: {
            amd: {
                files: grunt.moodleEnv.inComponent
                    ? ['amd/src/*.js', 'amd/src/**/*.js']
                    : ['**/amd/src/**/*.js'],
                tasks: ['amd']
            },
        },
    });

    // Add the 'js' task as a startup task.
    grunt.moodleEnv.startupTasks.push('js');

    // On watch, we dynamically modify config to build only affected files. This
    // method is slightly complicated to deal with multiple changed files at once (copied
    // from the grunt-contrib-watch readme).
    let changedFiles = Object.create(null);
    const onChange = grunt.util._.debounce(function() {
        const files = Object.keys(changedFiles);
        grunt.config('rollup.dist.files', [{expand: true, src: files, rename: babelRename}]);
        changedFiles = Object.create(null);
    }, 200);

    grunt.event.on('watch', function(action, filepath) {
        changedFiles[filepath] = action;
        onChange();
    });

    return {
        babelRename,
    };
};
